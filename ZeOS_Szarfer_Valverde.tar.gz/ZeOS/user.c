#include <libc.h>

char buff[24];
int pid;
int __attribute__ ((__section__(".text.main")))

main(void) {
  while(1) { }
}
